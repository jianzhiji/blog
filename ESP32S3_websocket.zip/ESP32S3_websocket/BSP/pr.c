#include "pr.h"
#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "driver/gpio.h"
#include "freertos/task.h"

void pr_init(void)
{
        vTaskDelay(1000);  // 延时1000ms
        printf("Hello pr!\n");

}