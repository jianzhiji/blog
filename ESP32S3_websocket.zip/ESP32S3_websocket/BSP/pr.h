#ifndef __pr_H__
#define __pr_H__

void pr_init(void);

#endif