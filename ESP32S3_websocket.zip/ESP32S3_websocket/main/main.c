#include <string.h>
#include "esp_log.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "nvs_flash.h"
#include "esp_netif.h"
#include "esp_http_server.h"
#include "esp_mac.h"

static const char *TAG = "ws_server";

// 定义WiFi名称
#define EXAMPLE_WIFI_SSID "ESP32-WS"
// 定义WiFi密码
#define EXAMPLE_WIFI_PASS "12345678"
// 定义最大连接STA数量
#define MAX_STA_CONN      1
// 声明一个外部常量，类型为uint8_t，表示index.html文件的起始位置
extern const uint8_t _binary_index_html_start[];
// 声明一个外部常量，类型为uint8_t，表示index.html文件的结束位置
extern const uint8_t _binary_index_html_end[];

static httpd_handle_t start_websocket_server(void);

//1. 握手阶段（Handshake
// 当客户端首次建立连接时发送HTTP GET请求（WebSocket握手）\
// 此阶段只需返回ESP_OK确认握手成功
esp_err_t ws_handler(httpd_req_t *req) {
    // 检查请求方法是否为GET
    if (req->method == HTTP_GET) {
        ESP_LOGI(TAG, "Handshake done, new connection");
        return ESP_OK;
    }
    // 初始化WebSocket帧，2. 接收WebSocket帧
    httpd_ws_frame_t ws_pkt;
    memset(&ws_pkt, 0, sizeof(httpd_ws_frame_t));
    ws_pkt.type = HTTPD_WS_TYPE_TEXT;

    // 获取帧长度
    esp_err_t ret = httpd_ws_recv_frame(req, &ws_pkt, 0);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to get frame length: %s", esp_err_to_name(ret));
        return ret;
    }

    // 如果帧长度大于0，则接收帧数据3. 处理有效载荷
    if (ws_pkt.len > 0) {
        // 分配内存
        uint8_t *buf = malloc(ws_pkt.len + 1);
        if (buf == NULL) {
            ESP_LOGE(TAG, "Failed to allocate memory for WebSocket payload");
            return ESP_ERR_NO_MEM;
        }

        ws_pkt.payload = buf;
        // 接收帧数据
        // 从HTTP请求中接收WebSocket帧
        ret = httpd_ws_recv_frame(req, &ws_pkt, ws_pkt.len);
        // 如果接收帧失败
        if (ret != ESP_OK) {
            // 打印错误信息
            ESP_LOGE(TAG, "Failed to receive frame: %s", esp_err_to_name(ret));
            // 释放缓冲区
            free(buf);
            // 返回错误码
            return ret;
        }

        buf[ws_pkt.len] = 0; // null terminate
        ESP_LOGI(TAG, "Received WebSocket message: %s", (char *)buf);

        // Echo back//回显帧数据
        // 定义一个httpd_ws_frame_t类型的变量response
        httpd_ws_frame_t response = {
            // 设置response的type为HTTPD_WS_TYPE_TEXT
            .type = HTTPD_WS_TYPE_TEXT,
            // 设置response的payload为buf
            .payload = buf,
            // 设置response的len为ws_pkt.len
            .len = ws_pkt.len,
            // 设置response的final为true
            .final = true
        };
        ret = httpd_ws_send_frame(req, &response);// 发送回显帧
        free(buf);
        return ret;
    }

    return ESP_OK;
}

// 处理根路径的GET请求,发送html文件
esp_err_t index_get_handler(httpd_req_t *req) {
    // return ESP_OK;
    // 设置响应类型为text/html
    httpd_resp_set_type(req, "text/html");
    // 发送index.html文件内容
    return httpd_resp_send(req, (const char *)_binary_index_html_start, _binary_index_html_end - _binary_index_html_start);
}

// 启动WebSocket服务器
static httpd_handle_t start_websocket_server(void) {
    // 声明一个httpd_handle_t类型的变量server，用于存储httpd_start函数返回的句柄
    httpd_handle_t server = NULL;
    // 声明一个httpd_config_t类型的变量config，用于存储httpd_start函数需要的配置参数
    httpd_config_t config = HTTPD_DEFAULT_CONFIG();

    // 设置uri匹配函数为httpd_uri_match_wildcard
    config.uri_match_fn = httpd_uri_match_wildcard;
    // 设置最大uri处理器的数量为16
    config.max_uri_handlers = 16;
    // 设置最大响应头的数量为16
    config.max_resp_headers = 16;
    // 设置最大打开的socket数量为4
    config.max_open_sockets = 4;

    // 调用httpd_start函数启动http服务器，并将返回的句柄存储在server变量中
    if (httpd_start(&server, &config) == ESP_OK) {
        // 声明一个httpd_uri_t类型的变量ws_uri，用于存储websocket的uri信息
        httpd_uri_t ws_uri = {
            .uri = "/ws",
            .method = HTTP_GET,
            .handler = ws_handler,//握手阶段,成功后升级通信协议为WebSocket
            .user_ctx = NULL,
            .is_websocket = true
        };
        httpd_register_uri_handler(server, &ws_uri);

        httpd_uri_t index_uri = {
            .uri = "/",
            .method = HTTP_GET,
            .handler = index_get_handler,//// 处理根路径的GET请求,发送html文件
            .user_ctx = NULL
        };
        httpd_register_uri_handler(server, &index_uri);
    }
    return server;
}

// 静态函数，用于初始化WiFi热点
static void wifi_init_softap(void) {
    // 初始化网络接口
    ESP_ERROR_CHECK(esp_netif_init());
    // 创建默认的事件循环
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    // 创建默认的WiFi热点接口
    esp_netif_create_default_wifi_ap();

    // 初始化WiFi配置
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    // 初始化WiFi
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));

    // 配置WiFi热点
    wifi_config_t wifi_config = {
        .ap = {
            .ssid = EXAMPLE_WIFI_SSID, // 设置WiFi热点名称
            .ssid_len = strlen(EXAMPLE_WIFI_SSID), // 设置WiFi热点名称长度
            .password = EXAMPLE_WIFI_PASS, // 设置WiFi热点密码
            .max_connection = MAX_STA_CONN, // 设置最大连接数
            .authmode = WIFI_AUTH_OPEN // 设置认证模式为开放
        },
    };
    // 设置WiFi模式为热点模式
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_AP));
    // 设置WiFi热点配置
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_AP, &wifi_config));
    // 启动WiFi热点
    ESP_ERROR_CHECK(esp_wifi_start());

    // 打印WiFi热点已启动的信息
    ESP_LOGI(TAG, "WiFi AP started. SSID:%s", EXAMPLE_WIFI_SSID);
}

void app_main(void) {
    // 初始化非易失性存储器
    ESP_ERROR_CHECK(nvs_flash_init());
    // 初始化软AP模式
    wifi_init_softap();
    // 启动WebSocket服务器
    start_websocket_server();
}
