#include "BSP_IIC.h"

esp_err_t i2c_master_init(void)//初始化i2c
{
    i2c_config_t conf = {
        // 设置I2C模式为主机模式
        .mode = I2C_MODE_MASTER,
        .sda_io_num = BSP_I2C_SDA,
        .scl_io_num = BSP_I2C_SCL,
        // 启用I2C数据线（SDA）的内部上拉电阻
        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        // 启用I2C时钟线（SCL）的内部上拉电阻
        .scl_pullup_en = GPIO_PULLUP_ENABLE,
        .master.clk_speed = BSP_IIC_FREQ_HZ,
    };

    i2c_param_config(BSP_I2C_NUM, &conf);//选择IIC0初始化
    //通常用来检查驱动程序是否成功安装。确保在调用 i2c_driver_install 之前，已经正确配置了 conf.mode 等参数。
    return i2c_driver_install(BSP_I2C_NUM, conf.mode, I2C_MASTER_RX_BUF_DISABLE, I2C_MASTER_TX_BUF_DISABLE, 0);
}
