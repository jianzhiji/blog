#ifndef __BSP_IIC_H
#define __BSP_IIC_H

// 包含ESP-IDF错误代码定义的头文件
#include "esp_err.h"
// 包含ESP-IDF日志记录功能的头文件
#include "esp_log.h"
// 包含I2C驱动程序的头文件，用于I2C通信
#include "driver/i2c.h"

// 再次包含ESP-IDF日志记录功能的头文件，可能是为了确保在其他地方也能使用
#include "esp_log.h"
// 包含FreeRTOS实时操作系统的头文件，用于任务管理和调度
#include "freertos/FreeRTOS.h"
// 包含FreeRTOS任务相关的头文件，用于创建和管理任务
#include "freertos/task.h"
// 包含数学函数的头文件，用于数学计算
#include "math.h"


#define BSP_I2C_SDA 1  //IO1
#define BSP_I2C_SCL 2

#define BSP_I2C_NUM 0 // I2C外设，选择IIC0
#define BSP_IIC_FREQ_HZ  100000 // 100kHz

#define I2C_MASTER_TX_BUF_DISABLE   0                          /*!< I2C master doesn't need buffer */
#define I2C_MASTER_RX_BUF_DISABLE   0   


esp_err_t i2c_master_init(void);//初始化i2c
 // 初始化I2C接口

#endif